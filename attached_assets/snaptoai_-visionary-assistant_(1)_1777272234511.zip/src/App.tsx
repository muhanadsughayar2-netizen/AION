/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Scissors, 
  FileText, 
  Star, 
  Play, 
  Settings, 
  Image as ImageIcon, 
  Music, 
  Video, 
  Send, 
  Plus, 
  X, 
  ChevronRight,
  Download,
  Copy,
  Trash2,
  Maximize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from '@google/genai';

// Initialize Gemini
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

interface Screenshot {
  id: string;
  url: string;
  timestamp: number;
}

export default function App() {
  const [view, setView] = useState<'popup' | 'chat'>('popup');
  const [screenshots, setScreenshots] = useState<Screenshot[]>([
    { id: '1', url: 'https://picsum.photos/seed/capture1/400/250', timestamp: Date.now() - 1000000 },
    { id: '2', url: 'https://picsum.photos/seed/capture2/400/250', timestamp: Date.now() - 500000 },
    { id: '3', url: 'https://picsum.photos/seed/capture3/400/250', timestamp: Date.now() - 200000 },
    { id: '4', url: 'https://picsum.photos/seed/capture4/400/250', timestamp: Date.now() - 50000 },
  ]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);

  const handleSnap = () => {
    setIsCapturing(true);
    setTimeout(() => {
      const newShot: Screenshot = {
        id: Math.random().toString(36).substr(2, 9),
        url: `https://picsum.photos/seed/${Math.random()}/800/500`,
        timestamp: Date.now(),
      };
      setScreenshots([newShot, ...screenshots]);
      setIsCapturing(false);
    }, 1000);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const deleteSelected = () => {
    setScreenshots(prev => prev.filter(s => !selectedIds.includes(s.id)));
    setSelectedIds([]);
  };

  return (
    <div className="min-h-screen bg-[#030305] text-[#F5F5F7] font-sans flex flex-col overflow-x-hidden relative">
      {/* Background Effects */}
      <div className="fixed inset-0 star-field pointer-events-none" />
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/10 blur-[150px] rounded-full pointer-events-none" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[150px] rounded-full pointer-events-none" />
      <div className="fixed top-[20%] right-[10%] w-[30%] h-[30%] bg-blue-600/5 blur-[120px] rounded-full pointer-events-none animate-pulse" />
      
      {/* Floating Orbs */}
      <motion.div 
        animate={{ y: [0, -20, 0], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="fixed top-[15%] left-[5%] w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none"
      />
      <motion.div 
        animate={{ y: [0, 20, 0], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 10, repeat: Infinity, delay: 2 }}
        className="fixed bottom-[15%] left-[15%] w-96 h-96 bg-purple-500/5 blur-[120px] rounded-full pointer-events-none"
      />

      {/* Navigation */}
      <nav className="h-20 px-6 md:px-20 flex items-center justify-between border-b border-white/5 shrink-0 sticky top-0 bg-[#030305]/80 backdrop-blur-xl z-50">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center shadow-2xl shadow-indigo-500/40">
            <Camera size={24} className="text-white" />
          </div>
          <span className="text-2xl font-black tracking-tighter uppercase italic font-display">Snap<span className="gradient-text pr-1">ToAI</span></span>
        </div>
        <div className="flex items-center gap-4 md:gap-8">
          <div className="hidden lg:flex items-center gap-2 bg-white/5 px-4 py-1.5 rounded-full border border-white/10 group cursor-help transition-all hover:bg-white/10">
            <span className="text-amber-400 text-xs font-black italic tracking-widest uppercase">Verified Studio</span>
            <div className="flex text-amber-400 text-[10px]">
              <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
            </div>
          </div>
          <button className="px-8 py-2.5 gradient-primary text-white font-black rounded-full hover:scale-105 transition-all uppercase text-[10px] tracking-[0.2em] shadow-2xl shadow-indigo-500/20">
            Deploy Extension
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative flex flex-col items-center justify-center px-6 md:px-20 py-24 min-h-screen">
        <div className="max-w-6xl w-full flex flex-col lg:flex-row items-center gap-16 lg:gap-24 relative z-10">
          <div className="w-full lg:w-1/2 flex flex-col gap-10">
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex self-start px-5 py-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded-full text-[10px] font-black tracking-[0.3em] uppercase"
            >
              Google AI Studio Payload Active
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <h1 className="text-6xl md:text-[100px] font-black leading-[0.85] tracking-tighter italic uppercase">
                SNAP THE <span className="gradient-text pr-8">PIXEL,</span><br/>
                UNLEASH <span className="underline decoration-indigo-500 underline-offset-12 gradient-text pr-8">THE STUDIO.</span>
              </h1>
            </motion.div>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-white/50 text-xl md:text-2xl max-w-xl leading-relaxed font-medium"
            >
              The definitive <span className="text-white font-black italic border-b border-white/20">Google AI Studio</span> bridge. Snap any screen to produce 4K Cinematic Video (VEO), Studio-grade Music (LYRIA), and photoreal imagery in 2 minutes.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-wrap gap-6"
            >
              <div className="flex flex-col">
                <span className="text-5xl font-black italic tracking-tighter">64S</span>
                <span className="text-[10px] uppercase text-white/30 tracking-[0.2em] font-black">Stitched Video</span>
              </div>
              <div className="w-px h-16 bg-white/10 hidden sm:block" />
              <div className="flex flex-col">
                <span className="text-5xl font-black italic tracking-tighter">12.4K</span>
                <span className="text-[10px] uppercase text-white/30 tracking-[0.2em] font-black">Active Studios</span>
              </div>
              <div className="w-px h-16 bg-white/10 hidden sm:block" />
              <div className="flex flex-col">
                <span className="text-5xl font-black italic tracking-tighter">$300</span>
                <span className="text-[10px] uppercase text-white/30 tracking-[0.2em] font-black">Free Credit</span>
              </div>
            </motion.div>
          </div>

          <div className="w-full lg:w-1/2 relative flex justify-center items-center py-10 floating">
            <div className="absolute w-[150%] h-[150%] cosmic-gradient animate-pulse pointer-events-none" />
            
            <AnimatePresence mode="wait">
              {view === 'popup' ? (
                <motion.div 
                  key="popup"
                  initial={{ opacity: 0, y: 40, scale: 0.9, rotateY: 20 }}
                  animate={{ opacity: 1, y: 0, scale: 1, rotateY: 0 }}
                  exit={{ opacity: 0, scale: 0.8, rotateY: -20 }}
                  className="w-full max-w-[420px] matte-glass rounded-[40px] overflow-hidden shadow-[0_45px_100px_rgba(0,0,0,0.8)] p-8 flex flex-col gap-8 relative border border-white/5"
                >
                  <div className="absolute top-0 left-0 right-0 h-[2px] gradient-primary opacity-60" />
                  
                  <header className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center shadow-xl shadow-indigo-500/40">
                        <Camera size={22} className="text-white" />
                      </div>
                      <span className="font-display font-black text-2xl tracking-tighter uppercase italic">
                        Snap<span className="gradient-text pr-1">ToAI</span>
                      </span>
                    </div>
                    <div className="bg-white/5 border border-white/10 px-4 py-1.5 rounded-full flex items-center gap-2 group transition-all hover:bg-white/10 cursor-pointer">
                      <span className="text-[9px] uppercase font-black text-white/40 tracking-widest">Tutorials</span>
                      <Play size={10} className="text-indigo-400 fill-indigo-400 group-hover:scale-110 transition-transform" />
                    </div>
                  </header>

                  <div className="grid grid-cols-4 gap-4">
                    <ActionButton icon={<Camera className="text-indigo-400" />} label="SNAP" onClick={handleSnap} isLoading={isCapturing} />
                    <ActionButton icon={<Scissors className="text-indigo-400" />} label="SNIP" onClick={() => {}} />
                    <ActionButton icon={<FileText className="text-indigo-400" />} label="FULL" onClick={() => {}} />
                    <ActionButton 
                      icon={<Star className="text-amber-400 fill-amber-400" />} 
                      label="STUDIO" 
                      variant="gold"
                      onClick={() => setView('chat')}
                    />
                  </div>

                  <div className="bg-white/3 border border-white/5 rounded-2xl py-4 px-6 flex items-center justify-between group cursor-help">
                    <div className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 active-pulse shadow-[0_0_12px_rgba(16,185,129,0.8)]" />
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30 italic">Studio.Payload v2.1</span>
                    </div>
                    <span className="text-[10px] font-black italic text-indigo-400/60 uppercase italic">Ready</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
                    {screenshots.map((s, idx) => (
                      <div 
                        key={s.id} 
                        className={`relative aspect-[16/10] rounded-2xl overflow-hidden cursor-pointer border-2 transition-all group ${selectedIds.includes(s.id) ? 'border-indigo-500 glow-indigo shadow-[0_0_20px_rgba(99,102,241,0.2)]' : 'border-white/5 hover:border-white/20'}`}
                        onClick={() => toggleSelect(s.id)}
                      >
                        <img src={s.url} alt="Screenshot" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" referrerPolicy="no-referrer" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex items-start justify-between p-3">
                          <div className={`w-5 h-5 rounded-lg border border-white/30 flex items-center justify-center transition-all ${selectedIds.includes(s.id) ? 'bg-indigo-500 border-indigo-500 shadow-lg' : 'bg-black/60 backdrop-blur-xl'}`}>
                            {selectedIds.includes(s.id) && <div className="w-1.5 h-1.5 rounded-full bg-white shadow-sm" />}
                          </div>
                          <span className="bg-indigo-500 text-white text-[9px] font-black px-2 py-1 rounded shadow-2xl italic uppercase tracking-tighter">Capture {idx + 1}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-col gap-3 pt-2">
                    <button 
                      onClick={() => { if (selectedIds.length === 0) setSelectedIds(screenshots.map(s => s.id)); setView('chat'); }}
                      className="w-full gradient-primary hover:opacity-90 text-white py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 shadow-[0_15px_40px_rgba(99,102,241,0.3)] italic"
                    >
                      <Plus size={16} fill="white" />
                      PROCESS IN STUDIO
                    </button>
                    <div className="grid grid-cols-2 gap-3 mt-1">
                      <button className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 text-white/40 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 group transition-all">
                        <Video size={14} className="group-hover:text-indigo-400" /> 64S VEO
                      </button>
                      <button className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 text-white/40 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 group transition-all">
                        <Music size={14} className="group-hover:text-pink-400" /> LYRIA 3
                      </button>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <AIChat 
                  screenshots={screenshots.filter(s => selectedIds.length === 0 || selectedIds.includes(s.id))} 
                  onClose={() => setView('popup')} 
                />
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-30"
        >
          <span className="text-[9px] font-black uppercase tracking-[0.5em] italic">Explore Studio</span>
          <div className="w-px h-12 bg-white/40" />
        </motion.div>
      </main>

      {/* Models / Features Showcase */}
      <section className="px-6 md:px-20 py-40 bg-white/[0.01] border-y border-white/5 relative overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-col gap-24 relative z-10">
          <div className="flex flex-col lg:flex-row items-end justify-between gap-12">
            <div className="max-w-2xl flex flex-col gap-6">
               <span className="text-indigo-400 text-xs font-black uppercase tracking-[0.5em]">Integrated Intelligence</span>
               <h2 className="text-5xl md:text-8xl font-black italic tracking-tighter leading-[0.8] uppercase">THE FULL GOOGLE AI<br/><span className="gradient-text pr-10">STUDIO PAYLOAD.</span></h2>
            </div>
            <p className="text-white/30 text-xl max-w-sm leading-relaxed mb-4 font-medium italic">
              Experience the pinnacle of generative AI, stiched directly into your browser workflow. One snap, infinite modes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<Video className="text-indigo-400" />} 
              title="VEO 3.1 PRODUCTION" 
              desc="8x8 stitching engine. Turn snaps into 64-second cinematic narratives in 4K resolution."
              label="Production"
            />
            <FeatureCard 
              icon={<Music className="text-pink-400" />} 
              title="LYRIA 3 AUDIO" 
              desc="Original music and studio-grade soundscapes tied to your visual context via Gemini reasoning."
              label="Scoring"
            />
            <FeatureCard 
              icon={<Camera className="text-emerald-400" />} 
              title="GEMINI 3 VISION" 
              desc="Pro-grade multi-source reasoning. Analyze 8 complex windows simultaneously with code support."
              label="Intelligence"
            />
            <FeatureCard 
              icon={<Star className="text-amber-400" />} 
              title="NANO BANANA 2" 
              desc="Next-gen photorealistic image generation. Infinite creativity from your daily captures."
              label="Creation"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 md:px-20 py-20 flex flex-col lg:flex-row items-center justify-between shrink-0 bg-black/40 gap-12 lg:gap-0 border-t border-white/5">
        <div className="flex flex-wrap justify-center lg:justify-start gap-12 md:gap-24">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] text-white/20 uppercase font-black tracking-[0.3em] italic">Technology</span>
            <span className="text-xs font-black uppercase italic tracking-tight text-white/40">Multimodal.Payload.v2.1</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] text-white/20 uppercase font-black tracking-[0.3em] italic">Backbone</span>
            <span className="text-xs font-black uppercase italic tracking-tight text-indigo-400/60">Google AI Studio (VEO/LYRIA)</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] text-white/20 uppercase font-black tracking-[0.3em] italic">Integrity</span>
            <span className="text-xs font-black text-emerald-400 uppercase italic tracking-tight underline pointer-events-none">Certified Pro Developer</span>
          </div>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 text-white/20 text-[9px] uppercase font-black tracking-[0.4em]">
           <span>Secured by Cloud</span>
           <span>No Card Required</span>
           <span>Studio Payloads Only</span>
        </div>
      </footer>
    </div>
  );
}

function ActionButton({ icon, label, variant = 'indigo', onClick, isLoading }: { icon: React.ReactNode, label: string, variant?: 'indigo' | 'gold', onClick: () => void, isLoading?: boolean }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <motion.button 
        whileHover={{ scale: 1.05, y: -2 }}
        whileTap={{ scale: 0.95 }}
        onClick={onClick}
        className={`w-[72px] h-[72px] rounded-2xl flex items-center justify-center text-2xl transition-all shadow-xl ${
          variant === 'gold' 
          ? 'bg-amber-400/10 border border-amber-400/30 glow-gold hover:bg-amber-400/20 shadow-amber-400/10' 
          : 'bg-white/5 border border-indigo-500/20 hover:border-indigo-500/50 hover:bg-indigo-500/10 shadow-indigo-500/5'
        } ${isLoading ? 'animate-pulse' : ''}`}
      >
        {icon}
      </motion.button>
      <span className={`text-[9px] font-black tracking-widest uppercase italic ${variant === 'gold' ? 'text-amber-400/60' : 'text-white/30'}`}>{label}</span>
    </div>
  );
}

function FeatureCard({ icon, title, desc, label }: { icon: React.ReactNode, title: string, desc: string, label: string }) {
  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="p-10 bg-white/[0.01] border border-white/5 rounded-[3rem] flex flex-col gap-8 group transition-all duration-700 hover:bg-white/[0.03] hover:border-white/10"
    >
      <div className="flex items-center justify-between">
        <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform duration-500 shadow-inner">
          {icon}
        </div>
        <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/10 group-hover:text-indigo-400 transition-colors">{label}</span>
      </div>
      <div className="flex flex-col gap-4 mt-2">
        <h3 className="text-xl font-bold tracking-tight text-white italic group-hover:gradient-text transition-all duration-500">{title}</h3>
        <p className="text-white/30 text-sm leading-relaxed font-medium">{desc}</p>
      </div>
    </motion.div>
  );
}

function AIChat({ screenshots, onClose }: { screenshots: Screenshot[], onClose: () => void }) {
  const [mode, setMode] = useState<'vision' | 'image' | 'music' | 'video'>('vision');
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string, type?: string}[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() && mode === 'vision') return;
    
    setIsProcessing(true);
    const userMsg = { role: 'user' as const, text: input || `Extracting context from ${screenshots.length} studio frames...` };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      let aiResponse = '';
      if (mode === 'vision') aiResponse = "Vision matrices locked. I've analyzed the photorealistic depth and structural intent of your captures. Integration with Gemini 3 suggests multiple pathing options for high-fidelity extraction.";
      else if (mode === 'image') aiResponse = "Synthesizing next-gen imagery assets. Textures are being upscaled to photoreal 4K quality based on your studio selection.";
      else if (mode === 'music') aiResponse = "Original LYRIA audio strands locked. The mood is cinematically layered with high-fidelity spatial harmonics.";
      else aiResponse = "VEO production engine engaged. Stitched frames are being processed through the 64-second narrative pipeline.";
      
      setMessages(prev => [...prev, { role: 'ai', text: aiResponse, type: mode }]);
      setIsProcessing(false);
    }, 1500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: 50 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 50 }}
      className="fixed inset-0 lg:p-12 z-[100] flex items-center justify-center pointer-events-none"
    >
      <div className="w-full h-full max-w-7xl matte-glass lg:rounded-[4rem] overflow-hidden flex flex-col lg:flex-row shadow-[0_100px_300px_rgba(0,0,0,0.9)] pointer-events-auto relative">
        <div className="absolute top-0 left-0 right-0 h-[2px] gradient-primary opacity-40" />

        {/* Studio Sidebar: Context Assets */}
        <div className="w-full lg:w-[360px] bg-black/40 border-b lg:border-b-0 lg:border-r border-white/5 flex flex-col gap-8 p-10 shrink-0">
          <div className="flex items-center justify-between">
            <h3 className="text-[11px] font-black uppercase tracking-[0.5em] text-white/20 italic">Context Feed</h3>
            <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-all">
              <X size={20} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-4">
            {screenshots.map((s, idx) => (
              <motion.div 
                key={s.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="group relative aspect-[16/9] rounded-3xl overflow-hidden border border-white/5 hover:border-indigo-500/50 transition-all shadow-2xl"
              >
                <img src={s.url} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors" />
                <div className="absolute top-3 right-3 px-3 py-1 bg-black/60 backdrop-blur-xl rounded-lg text-[9px] font-black uppercase tracking-tighter text-white/60 flex items-center gap-2 border border-white/5 shadow-2xl">
                   <div className="w-1 h-1 rounded-full bg-indigo-500" />
                   REF {idx + 1}
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-[8px] font-black uppercase tracking-widest text-white italic bg-indigo-500 px-2 py-0.5 rounded shadow-lg">4K Capture</span>
                  <span className="text-[8px] font-black uppercase tracking-widest text-white/40 italic bg-black/60 px-2 py-0.5 rounded backdrop-blur-md">8-bit depth</span>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="bg-indigo-500/5 border border-indigo-500/10 rounded-[2rem] p-6 flex flex-col gap-4">
             <div className="flex items-center gap-3">
               <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 active-pulse shadow-[0_0_12px_rgba(99,102,241,0.8)]" />
               <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400">STUDIO_LINK ACTIVE</span>
             </div>
             <div className="space-y-2">
               <div className="flex justify-between text-[8px] font-black uppercase tracking-widest text-white/20 italic">
                 <span>Bandwidth</span>
                 <span className="text-white/40">1.2 GB/s</span>
               </div>
               <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                 <motion.div initial={{ width: 0 }} animate={{ width: '85%' }} transition={{ duration: 2 }} className="h-full gradient-primary" />
               </div>
               <div className="flex justify-between text-[8px] font-black uppercase tracking-widest text-white/20 italic">
                 <span>Latency</span>
                 <span className="text-emerald-400">12ms</span>
               </div>
             </div>
          </div>
        </div>

        {/* Creative Production Studio */}
        <div className="flex-1 flex flex-col bg-black/20 backdrop-blur-3xl relative">
          <header className="h-[120px] px-12 border-b border-white/5 flex items-center justify-between">
             <div className="flex items-center gap-10">
                <StudioTab active={mode === 'vision'} icon={<Camera size={20} />} label="Vision" onClick={() => setMode('vision')} />
                <StudioTab active={mode === 'image'} icon={<Star size={20} />} label="Studio" onClick={() => setMode('image')} />
                <StudioTab active={mode === 'music'} icon={<Music size={20} />} label="Lyria" onClick={() => setMode('music')} />
                <StudioTab active={mode === 'video'} icon={<Video size={20} />} label="Veo" onClick={() => setMode('video')} />
             </div>
             
             <div className="hidden lg:flex items-center gap-4 bg-white/5 px-6 py-2.5 rounded-2xl border border-white/5">
                <span className="text-[11px] font-black uppercase tracking-[0.3em] text-white/20 italic">Payload v2.1</span>
                <div className="w-[1px] h-4 bg-white/10" />
                <span className="text-[11px] font-black uppercase tracking-[0.1em] text-indigo-400 italic">STUDIO_ENV_LIVE</span>
             </div>
          </header>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-12 flex flex-col gap-10 custom-scrollbar scroll-smooth">
            {messages.length === 0 && (
              <div className="flex-1 flex flex-col items-center justify-center text-center gap-8 opacity-20">
                 <div className="w-24 h-24 rounded-[2rem] border border-white/10 flex items-center justify-center backdrop-blur-3xl shadow-inner">
                   <Camera size={48} className="text-white" />
                 </div>
                 <div className="flex flex-col gap-3">
                   <h2 className="text-4xl font-black uppercase tracking-[0.2em] italic underline decoration-indigo-500 decoration-4 underline-offset-12 tracking-tighter">Awaiting Production</h2>
                   <p className="text-xs uppercase tracking-[0.3em] font-black text-white/40 italic">Deploy creative commands to start extraction</p>
                 </div>
              </div>
            )}
            {messages.map((m, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'} gap-3 mb-4`}
              >
                <div className={`max-w-[75%] rounded-[2rem] px-10 py-7 text-base font-medium leading-relaxed shadow-2xl relative group ${
                  m.role === 'user' 
                  ? 'bg-white text-black font-bold uppercase italic tracking-tight shadow-white/5' 
                  : 'studio-bubble text-white/80'
                }`}>
                  <div className="relative z-10">{m.text}</div>
                  {m.role === 'ai' && (
                    <motion.div 
                      className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-transparent"
                      animate={{ x: ['-100%', '100%'] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    />
                  )}
                </div>
                <div className="flex items-center gap-3 px-6">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/20 italic">
                    {m.role === 'user' ? 'Creator' : (m.type ? `Studio Node: ${m.type}` : 'System Output')}
                  </span>
                  <div className="w-[100px] h-[1px] bg-white/5" />
                  {m.role === 'ai' && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 active-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />}
                </div>
              </motion.div>
            ))}
            {isProcessing && (
              <div className="flex gap-3 p-6 text-indigo-400">
                <motion.div animate={{ opacity: [1, 0.4, 1], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 rounded-full bg-current" />
                <motion.div animate={{ opacity: [1, 0.4, 1], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 rounded-full bg-current" />
                <motion.div animate={{ opacity: [1, 0.4, 1], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 rounded-full bg-current" />
              </div>
            )}
          </div>

          <div className="p-12 pt-0">
            <div className="relative group">
               <input 
                 type="text" 
                 value={input}
                 onChange={(e) => setInput(e.target.value)}
                 onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                 placeholder={`Command ${mode} studio...`}
                 className="w-full bg-black/40 border border-white/10 rounded-[2rem] px-10 py-6 text-lg text-white font-medium placeholder:text-white/10 focus:outline-none focus:border-indigo-500/40 transition-all focus:bg-black/60 shadow-[0_50px_100px_rgba(0,0,0,0.5)]"
               />
               <button 
                 onClick={handleSend}
                 className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 gradient-primary rounded-2xl flex items-center justify-center hover:scale-110 transition-all shadow-2xl shadow-indigo-600/30"
               >
                 <Plus className="text-white rotate-45" size={28} />
               </button>
            </div>
            <div className="mt-6 flex items-center justify-center gap-8">
               <div className="flex items-center gap-2 text-white/20">
                 <div className="w-1 h-1 rounded-full bg-current" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] italic">E2E Studio Encryption</span>
               </div>
               <div className="flex items-center gap-2 text-white/20">
                 <div className="w-1 h-1 rounded-full bg-current" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] italic">Private Studio Model Node</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function StudioTab({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-4 transition-all group relative py-3 ${active ? 'text-white' : 'text-white/20 hover:text-white/50'}`}
    >
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${active ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 glow-indigo' : 'bg-white/5'}`}>
        {icon}
      </div>
      <span className="text-xs font-black uppercase tracking-[0.3em] italic">{label}</span>
      {active && (
        <motion.div 
          layoutId="activeTab"
          className="absolute -bottom-2 left-0 right-0 h-[3px] gradient-primary shadow-[0_0_20px_rgba(99,102,241,0.6)]"
        />
      )}
    </button>
  );
}

function Suggestion({ label }: { label: string }) {
  return (
    <button className="flex-shrink-0 bg-white/5 hover:bg-white/10 border border-white/10 px-4 py-1.5 rounded-full text-[10px] font-bold text-white/60 transition-all uppercase tracking-wider">
      {label}
    </button>
  );
}
